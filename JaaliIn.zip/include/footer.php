                <div class="container">
                    <div class="row">
                        
                        <div class="col-md-6">
                            <div class="newsletter">
                                <h4>A propos de nous</h4>
                                <p>Menuiserie est un constructeur et designer de bois qui utilise de moderne machine CNC. Nous sommes basés à Nador, Maroc.</p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="contact-details">
                                <h4>Nous contacter</h4>
                                <ul class="contact">
                                    <li><p><i class="icon icon-map-marker"></i> <strong>Adresse:</strong> 201, Imm X, Sélouane, Nador, Maroc 62000</p></li>
                                    <li><p><i class="icon icon-phone"></i> <strong>Téléphone Fix:</strong> +212 5 36 60 55 00</p></li>
                                    <li><p><i class="icon icon-phone"></i> <strong>Téléphone Mobile:</strong> +212 6 72 34 55 44</p></li>
                                    <li><p><i class="icon icon-envelope"></i> <strong>Email:</strong> <a href="mailto:menuiserie@gmail.com">menuiserie@gmail.com</a></p></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="footer-copyright">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-1">
                                <a href="index.html" class="logo">
                                    <img alt="Jaali.in" class="img-responsive" src="img/logo2-footer.png">
                                </a>
                            </div>
                            <div class="col-md-7">
                                <p style="color:#E2E2E2;">© Copyright 2016. Tous droits réservés. <!--Created by <a href="http://www.ibbisoft.com">Ibbi Software Inc.</a--></p>
                            </div>
                            <div class="col-md-4">
                                <nav id="sub-menu">
                                    <ul>
                                        <img alt="Sign-O-Craft" class="img-responsive" src="img/Signocraft_Logo.png">
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>