                    <div class="slider" id="revolutionSlider">
                        <ul>
                            <li data-transition="fade" data-slotamount="13" data-masterspeed="300" >
                                <img src="img/slides/Slide_1.jpg" data-bgrepeat="no-repeat" data-bgfit="contain" data-bgposition="center center">
                            </li>
                            <li data-transition="fade" data-slotamount="13" data-masterspeed="300" >
                                <img src="img/slides/Slide_2.jpg" data-bgrepeat="no-repeat" data-bgfit="contain" data-bgposition="center center">
                            </li>
                            <li data-transition="fade" data-slotamount="13" data-masterspeed="300" >
                                <img src="img/slides/Slide_3.jpg" data-bgrepeat="no-repeat" data-bgfit="contain" data-bgposition="center center">
                            </li>
                            <li data-transition="fade" data-slotamount="13" data-masterspeed="300" >
                                <img src="img/slides/Slide_4.jpg" data-bgrepeat="no-repeat" data-bgfit="contain" data-bgposition="center center">
                            </li>
                            <li data-transition="fade" data-slotamount="13" data-masterspeed="300" >
                                <img src="img/slides/Slide_5.jpg" data-bgrepeat="no-repeat" data-bgfit="contain" data-bgposition="center center">
                            </li>
                            <li data-transition="fade" data-slotamount="13" data-masterspeed="300" >
                                <img src="img/slides/Slide_6.jpg" data-bgrepeat="no-repeat" data-bgfit="contain" data-bgposition="center center">
                            </li>
                            <li data-transition="fade" data-slotamount="13" data-masterspeed="300" >
                                <img src="img/slides/Slide_7.jpg" data-bgrepeat="no-repeat" data-bgfit="contain" data-bgposition="center center">
                            </li>
                            <li data-transition="fade" data-slotamount="13" data-masterspeed="300" >
                                <img src="img/slides/Slide_8.jpg" data-bgrepeat="no-repeat" data-bgfit="contain" data-bgposition="center center">
                            </li>
                            <li data-transition="fade" data-slotamount="13" data-masterspeed="300" >
                                <img src="img/slides/Slide_9.jpg" data-bgrepeat="no-repeat" data-bgfit="contain" data-bgposition="center center">
                            </li>
                        </ul>
                    </div>